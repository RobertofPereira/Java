# Java
<b>Desenvolvimento de Sistemas Web III</b>

* Compilador Java <a href="https://www.online-java.com/"> Online </a>
* Google Classroom: vh52anc
* Material complementar: <a href="https://fishy-ostrich-493.notion.site/Desenvolvimento-de-sistemas-Web-III-8493e6a9372e4347a06a9a01b7f60106"> Notion </a>
* Diagramas e fluxogramas: <a href="https://draw.io"> draw.io </a>
* Tabela Unicode <a href="https://andersonneto.blogspot.com/2014/04/tabela-unicode-java.html"> JAVA </a>

<b> Visual Studio Code </b>
* Extension Pack for Java
* Java Code Generators

<b> Banco de Dados </b>
* MySQL Workbench <a href="https://www.mysql.com/products/workbench/"> Download </a>

<!--

https://astah.net/pricing/academic/

https://www.4devs.com.br/

-->
